# Building a Simple Chatbot in Python (using NLTK)

Gartner estimates that by 2020, chatbots will be handling 85 percent of customer-service interactions; they are already handling about 30 percent of transactions now.

This is the Repository linked with my published article on Medium with the same title. Please find the link to the article [here](https://medium.com/analytics-vidhya/building-a-simple-chatbot-in-python-using-nltk-7c8c8215ac6e)
